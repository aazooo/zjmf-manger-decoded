const refundDialog = {
    template: `
        <div>这是退款弹窗</div>
    `,
    created() {

    },
    data() {
        return {

        }
    },
    methods: {

    },
}