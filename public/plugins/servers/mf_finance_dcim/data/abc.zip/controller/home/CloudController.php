<?php
namespace reserver\mf_finance_dcim\controller\home;

use app\common\model\HostModel;
use app\common\model\MenuModel;
use app\common\model\UpstreamProductModel;
use reserver\mf_finance_dcim\logic\RouteLogic;
use reserver\mf_finance_dcim\model\SystemLogModel;
use think\facade\Cache;

/**
 * @title V10代理魔方财务DCIM-前台
 * @desc V10代理魔方财务DCIM-前台
 * @use reserver\mf_finance_dcim\controller\home\CloudController
 */
class CloudController
{
    /**
     * 时间 2023-02-06
     * @title 获取订购页面配置
     * @desc 获取订购页面配置
     * @url /console/v1/product/:id/remf_finance_dcim/order_page
     * @method  GET
     * @author wyh
     * @version v1
     * @param   int id - 商品ID require
     *
     */
    public function orderPage(){
        $param = request()->param();

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByProduct($param['id']);

            $postData = [
                'pid' => $RouteLogic->upstream_product_id,
                'billingcycle' => $param['billingcycle']??''
            ];

            $result = $RouteLogic->curl( 'cart/set_config', $postData, 'GET');
            /*if($result['status'] == 200){
                // 计算价格倍率
                if(isset($result['option'])){
                    foreach($result['option'] as $k=>$v){
                        if($v['pricing']>0){
                            $result['option'][$k]['pricing'] = bcmul($v['pricing'], $RouteLogic->price_multiple);
                        }
                    }
                }
                if (isset($result['product']['cycle'])){
                    foreach ($result['product']['cycle'] as $k1=>$v1){
                        $result['product']['cycle'][$k1]['product_price'] = bcmul($v1['product_price'], $RouteLogic->price_multiple);
                    }
                }
            }*/
        }catch(\Exception $e){
            $result = json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception') . $e->getMessage()]);
        }
        return json($result);
    }

    /**
     * 时间 2023-02-06
     * @title 获取订购页面配置
     * @desc 获取订购页面配置(层级联动)
     * @url /console/v1/product/:id/remf_finance/link
     * @method  GET
     * @author wyh
     * @version v1
     * @param   int id - 商品ID require
     * @param   int cid - 配置项ID require
     * @param   int sub_id - 子项ID require
     *
     */
    public function link(){
        $param = request()->param();

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByProduct($param['id']);

            $postData = [
                'pid' => $RouteLogic->upstream_product_id,
                'cid' => $param['cid'],
                'sub_id' => $param['sub_id'],
                'billingcycle' => $param['billingcycle']??''
            ];

            $result = $RouteLogic->curl( 'link_list', $postData, 'GET');
            /*if($result['status'] == 200){
                // 计算价格倍率
                if(isset($result['option'])){
                    foreach($result['option'] as $k=>$v){
                        if($v['pricing']>0){
                            $result['option'][$k]['pricing'] = bcmul($v['pricing'], $RouteLogic->price_multiple);
                        }
                    }
                }
                if (isset($result['product']['cycle'])){
                    foreach ($result['product']['cycle'] as $k1=>$v1){
                        $result['product']['cycle'][$k1]['product_price'] = bcmul($v1['product_price'], $RouteLogic->price_multiple);
                    }
                }
            }*/
        }catch(\Exception $e){
            $result = json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_act_exception') . $e->getMessage()]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-29
     * @title 获取实例详情
     * @desc 获取实例详情
     * @url /console/v1/remf_finance_dcim/:id
     * @method  GET
     * @author hh
     * @version v1
     * @param   int $id - 产品ID
     * @return host_data:基础数据@
     * @host_data  ordernum:订单id
     * @host_data  productid:产品id
     * @host_data  serverid:服务器id
     * @host_data  regdate:产品开通时间
     * @host_data  domain:主机名
     * @host_data  payment:支付方式
     * @host_data  firstpaymentamount:首付金额
     * @host_data  firstpaymentamount_desc:首付金额
     * @host_data  amount:续费金额
     * @host_data  amount_desc:续费金额
     * @host_data  billingcycle:付款周期
     * @host_data  billingcycle_desc:付款周期
     * @host_data  nextduedate:到期时间
     * @host_data  nextinvoicedate:下次帐单时间
     * @host_data  dedicatedip:独立ip
     * @host_data  assignedips:附加ip
     * @host_data  ip_num:IP数量
     * @host_data  domainstatus:产品状态
     * @host_data  domainstatus_desc:产品状态
     * @host_data  username:服务器用户名
     * @host_data  password:服务器密码
     * @host_data  suspendreason:暂停原因
     * @host_data  auto_terminate_end_cycle:是否到期取消
     * @host_data  auto_terminate_reason:取消原因
     * @host_data  productname:产品名
     * @host_data  groupname:产品组名
     * @host_data  bwusage:当前使用流量
     * @host_data  bwlimit:当前使用流量上限(0表示不限)
     * @host_data  os:操作系统
     * @host_data  port:端口
     * @host_data  remark:备注
     * @return config_options:可配置选项@
     * @config_options  name:配置名
     * @config_options  sub_name:配置项值
     * @return custom_field_data:自定义字段@
     * @custom_field_data  fieldname:字段名
     * @custom_field_data  value:字段值
     * @return download_data:可下载数据@
     * @download_data  id:文件id
     * @title  id:文件标题
     * @down_link  id:下载链接
     * @location  id:文件名
     * @return module_button:模块按钮@
     * @module_button  type:default:默认,custom:自定义
     * @module_button  type:func:函数名
     * @module_button  type:name:名称
     * @return module_client_area:模块页面输出
     * @return hook_output:钩子在本页面的输出，数组，循环显示的html
     * @return dcim.flowpacket:当前产品可购买的流量包@
     * @dcim.flowpacket  id:流量包ID
     * @dcim.flowpacket  name:流量包名称
     * @dcim.flowpacket  price:价格
     * @dcim.flowpacket  sale_times:销售次数
     * @dcim.flowpacket  stock:库存(0不限)
     * @return dcim.auth:服务器各种操作权限控制(on有权限off没权限)
     * @return dcim.area_code:区域代码
     * @return dcim.area_name:区域名称
     * @return dcim.os_group:操作系统分组@
     * @dcim.os_group  id:分组ID
     * @dcim.os_group  name:分组名称
     * @dcim.os_group  svg:分组svg号
     * @return dcim.os:操作系统数据@
     * @dcim.os  id:操作系统ID
     * @dcim.os  name:操作系统名称
     * @dcim.os  ostype:操作系统类型(1windows0linux)
     * @dcim.os  os_name:操作系统真实名称(用来判断具体的版本和操作系统)
     * @dcim.os  group_id:所属分组ID
     * @return  flow_packet_use_list:流量包使用情况@
     * @flow_packet_use_list  name:流量包名称
     * @flow_packet_use_list  capacity:流量包大小
     * @flow_packet_use_list  price:价格
     * @flow_packet_use_list  pay_time:支付时间
     * @flow_packet_use_list  used:已用流量
     * @flow_packet_use_list  used:已用流量
     * @return  host_cancel: 取消请求数据,空对象
     */
    public function detail(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $result = $RouteLogic->curl( 'host/header', ['host_id'=>$RouteLogic->upstream_host_id], 'GET');
            if ($result['status']==200){
                if (!isset($result['system_button'])){
                    $result['system_button'] = [];
                }
            }
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        if ($result['status']!=200){
            $result['status'] = 400;
        }
        return json($result);
    }

    /**
     * 时间 2022-06-22
     * @title 开机
     * @desc 开机
     * @url /console/v1/remf_finance_dcim/:id/on
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     */
    public function on()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'is_api'    => true
            ];

            $result = $RouteLogic->curl('dcim/on', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_boot_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_boot_fail', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-22
     * @title 关机
     * @desc 关机
     * @url /console/v1/remf_finance_dcim/:id/off
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     */
    public function off()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'is_api'    => true
            ];

            $result = $RouteLogic->curl( 'dcim/off', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_off_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_off_fail', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-22
     * @title 重启
     * @desc 重启
     * @url /console/v1/remf_finance_dcim/:id/reboot
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     */
    public function reboot()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'is_api'    => true
            ];

            $result = $RouteLogic->curl( 'dcim/reboot', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reboot_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reboot_fail', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-22
     * @title 重置BMC
     * @desc 重置BMC
     * @url /console/v1/remf_finance_dcim/:id/reset_bmc
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     */
    public function resetBmc()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'is_api'    => true
            ];

            $result = $RouteLogic->curl( 'dcim/bmc', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reset_bmc_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reset_bmc_fail', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-29
     * @title 获取控制台地址(TODO)
     * @desc 获取控制台地址
     * @url /console/v1/remf_finance_dcim/:id/vnc
     * @method  POST
     * @author hh
     * @version v1
     * @return  string data.url - 控制台地址
     */
    public function vnc()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'is_api'    => true
            ];

            $result = $RouteLogic->curl( 'dcim/novnc', $postData, 'POST');
            if($result['status'] == 200){
                $cache = $result['data'];
                unset($result['data']);

                Cache::set('remf_finance_dcim_vnc_'.$param['id'], $cache, 30*60);
                // 转到当前res模块
                $result['data']['url'] = request()->domain().'/console/v1/remf_finance_dcim/'.$param['id'].'/vnc?tmp_token='.$cache['token'];
            }

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-07-01
     * @title 控制台页面
     * @desc 控制台页面
     * @url /console/v1/remf_finance_dcim/:id/vnc
     * @method  GET
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     */
    public function vncPage(){
        $param = request()->param();

        $cache = Cache::get('remf_finance_dcim_vnc_'.$param['id']);
        if(!empty($cache) && isset($param['tmp_token']) && $param['tmp_token'] === $cache['token']){
            View::assign($cache);
        }else{
            return lang_plugins('res_remf_finance_dcim_vnc_token_expired_please_reopen');
        }
        return View::fetch(WEB_ROOT . 'plugins/reserver/mf_dcim/view/vnc_page.html');
    }

    /**
     * 时间 2022-06-24
     * @title 获取实例状态
     * @desc 获取实例状态
     * @url /console/v1/remf_finance_dcim/:id/status
     * @method  GET
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     * @return  string data.status - 实例状态(on=开机,off=关机,operating=操作中,fault=故障)
     * @return  string data.desc - 实例状态描述
     */
    public function status()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'is_api'    => true
            ];

            $res = $RouteLogic->curl( 'dcim/refresh_power_status', $postData, 'POST');
            if($res['status'] == 200){
                if($res['data']['power'] == 'not_support'){
                    $status = [
                        'status' => 'fault',
                        'desc'   => lang_plugins('res_mf_finance_dcim_fault'),
                    ];
                }else if($res['data']['power'] == 'on'){
                    $status = [
                        'status' => 'on',
                        'desc'   => lang_plugins('res_mf_finance_dcim_on'),
                    ];
                }else if($res['data']['power'] == 'off'){
                    $status = [
                        'status' => 'off',
                        'desc'   => lang_plugins('res_mf_finance_dcim_off')
                    ];
                }else{
                    $status = [
                        'status' => 'fault',
                        'desc'   => lang_plugins('res_mf_finance_dcim_fault'),
                    ];
                }
            }else{
                $status = [
                    'status' => 'fault',
                    'desc'   => lang_plugins('res_mf_finance_dcim_fault'),
                ];
            }

            $result = [
                'status' => 200,
                'msg'    => lang_plugins('success_message'),
                'data'   => $status,
            ];
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-24
     * @title 重置密码
     * @desc 重置密码
     * @url /console/v1/remf_finance_dcim/:id/reset_password
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     * @param   string password - 新密码 require
     */
    public function resetPassword()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'            => $RouteLogic->upstream_host_id,
                'password'      => $param['password'] ?? '',
                'is_api' => true
            ];

            $result = $RouteLogic->curl( 'dcim/crack_pass', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reset_password_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reset_password_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-24
     * @title 救援模式
     * @desc 救援模式
     * @url /console/v1/remf_finance_dcim/:id/rescue
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     * @param   int type - 指定救援系统类型(1=windows,2=linux) require
     */
    public function rescue()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'system'    => $param['type'] == 2 ? 1 : 2,
                'is_api'    => true
            ];

            $result = $RouteLogic->curl( 'dcim/rescue', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_rescue_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_rescue_fail', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-06-30
     * @title 重装系统
     * @desc 重装系统
     * @url /console/v1/remf_finance_dcim/:id/reinstall
     * @method  POST
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     * @param   int os - 重装系统的操作系统id require
     * @param   string password - 密码 require
     * @param   int port - 端口 require
     */
    public function reinstall()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'        => $RouteLogic->upstream_host_id,
                'os'        => $param['os'] ?? '',
                'password'  => $param['password'] ?? '',
                'port'      => $param['port'] ?? '',
                'is_api'    => true
            ];

            $result = $RouteLogic->curl( 'dcim/reinstall', $postData, 'POST');
            if($result['status'] == 200){
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reinstall_success', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }else{
                $description = lang_plugins('res_mf_finance_dcim_log_host_start_reinstall_fail', [
                    '{hostname}' => $HostModel['name'],
                ]);
            }
            active_log($description, 'host', $HostModel['id']);
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2020-07-06
     * @title 获取模块图表数据
     * @desc 获取模块图表数据
     * @url /console/v1/remf_finance_dcim/:id/chart
     * @method  GET
     * @author hh
     * @version v1
     * @param   int id - 产品ID require
     * @param   int start_time - 开始秒级时间
     * @return  array list - 图表数据
     * @return  int list[].time - 时间(秒级时间戳)
     * @return  float list[].in_bw - 进带宽
     * @return  float list[].out_bw - 出带宽
     * @return  string unit - 当前单位
     */
    public function chart()
    {
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        $data = [];

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'id'            => $RouteLogic->upstream_host_id,
                'start_time'    => isset($param['start_time']) ? $param['start_time'].'000' : '',
                'type'          => 'server',
                // 'switch_id'     => $RouteLogic->upstream_host_id,
                'is_api'        => true
            ];

            $res = $RouteLogic->curl( '/dcim/traffic', $postData, 'POST');
            if(isset($res['data']['traffic'])){
                foreach($res['data']['traffic'] as $v){
                    if(!isset($data['list'][$v['time']])){
                        $data['list'][$v['time']] = [
                            'time'   => $v['time']/1000,
                            'in_bw'  => round($v['value'], 2),
                            'out_bw' => 0,
                        ];
                    }else{
                        $data['list'][$v['time']]['out_bw'] = round($v['value'], 2);
                    }
                }
                $data['unit'] = $res['data']['unit'];

                $data['list'] = array_values($data['list']);
            }
            
            $result = [
                'status' => 200,
                'msg'    => lang_plugins('success_message'),
                'data'   => $data,
            ];
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * 时间 2022-09-26
     * @title 获取商品配置所有周期价格
     * @desc 获取商品配置所有周期价格
     * @url /console/v1/product/:id/remf_finance_dcim/duration
     * @method  GET
     * @author wyh
     * @version v1
     * @param   int id - 商品ID require
     * @return object duration - 周期
     * @return float duration.product_price - 价格
     * @return float duration.setup_fee - 初装费
     * @return string duration.billingcycle - 周期
     * @return string duration.billingcycle_zh - 周期
     * @return string duration.pay_ontrial_cycle - 试用
     */
    public function cartConfigoption()
    {
        $param = request()->param();

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByProduct($param['id']);

            unset($param['id']);

            $postData = [
                'pid' => $RouteLogic->upstream_product_id,
                'billingcycle' => $param['billingcycle']??''
            ];

            $result = $RouteLogic->curl( 'cart/set_config', $postData, 'GET');
            if($result['status'] == 200){
                // 计算价格倍率
                foreach($result['product']['cycle'] as $k=>$v){
                    if($v['product_price'] > 0){
                        $result['product']['cycle'][$k]['product_price'] = bcmul($v['product_price'], $RouteLogic->price_multiple);
                    }
                    if($v['setup_fee'] > 0){
                        $result['product']['cycle'][$k]['setup_fee'] = bcmul($v['setup_fee'], $RouteLogic->price_multiple);
                    }
                }
                $res = [
                    'status' => 200,
                    'msg' => $result['msg'],
                    'data' => [
                        'duration' => $result['product']['cycle']??[]
                    ]
                ];
                return json($res);
            }else{
                return json($result);
            }
        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
    }

    /**
     * 时间 2023-02-09
     * @title 产品列表
     * @desc 产品列表
     * @url /console/v1/remf_finance_dcim
     * @method  GET
     * @author hh
     * @version v1
     * @param   int page 1 页数
     * @param   int limit - 每页条数
     * @param   string orderby - 排序(id,due_time,status)
     * @param   string sort - 升/降序
     * @param   string keywords - 关键字搜索,搜索套餐名称/主机名/IP
     * @param   string param.status - 产品状态(Unpaid=未付款,Pending=开通中,Active=已开通,Suspended=已暂停,Deleted=已删除)
     * @param   int param.m - 菜单ID
     * @return  array data.list - 列表数据
     * @return  int data.list[].id - 产品ID
     * @return  string data.list[].name - 产品标识
     * @return  string data.list[].status - 产品状态(Unpaid=未付款,Pending=开通中,Active=已开通,Suspended=已暂停,Deleted=已删除)
     * @return  int data.list[].due_time - 到期时间
     * @return  int data.list[].active_time - 开通时间
     * @return  string data.list[].product_name - 商品名称
     */
    public function list(){
        $param = request()->param();

        $result = [
            'status' => 200,
            'msg'    => lang_plugins('success_message'),
            'data'   => [
                'list'  => [],
                'count' => [],
            ]
        ];

        $clientId = get_client_id();
        if(empty($clientId)){
            return json($result);
        }

        $where = [];
        if(isset($param['m']) && !empty($param['m'])){
            // 菜单,菜单里面必须是下游商品
            $MenuModel = MenuModel::where('menu_type', 'res_module')
                ->where('module', 'mf_finance_dcim')
                ->where('id', $param['m'])
                ->find();
            if(!empty($MenuModel) && !empty($MenuModel['product_id'])){
                $MenuModel['product_id'] = json_decode($MenuModel['product_id'], true);
                if(!empty($MenuModel['product_id'])){
                    $upstreamProduct = UpstreamProductModel::whereIn('product_id', $MenuModel['product_id'])->where('res_module', 'mf_finance_dcim')->find();
                    if(!empty($upstreamProduct)){
                        $where[] = ['h.product_id', 'IN', $MenuModel['product_id'] ];
                    }
                }
            }
        }else{
            //return json($result);
        }

        $param['page'] = isset($param['page']) ? ($param['page'] ? (int)$param['page'] : 1) : 1;
        $param['limit'] = isset($param['limit']) ? ($param['limit'] ? (int)$param['limit'] : config('idcsmart.limit')) : config('idcsmart.limit');
        $param['sort'] = isset($param['sort']) ? ($param['sort'] ?: config('idcsmart.sort')) : config('idcsmart.sort');
        $param['orderby'] = isset($param['orderby']) && in_array($param['orderby'], ['id','due_time','status']) ? $param['orderby'] : 'id';
        $param['orderby'] = 'h.'.$param['orderby'];

        $where[] = ['h.client_id', '=', $clientId];
        $where[] = ['h.status', '<>', 'Cancelled'];
        if(isset($param['status']) && !empty($param['status'])){
            if($param['status'] == 'Pending'){
                $where[] = ['h.status', 'IN', ['Pending','Failed']];
            }else if(in_array($param['status'], ['Unpaid','Active','Suspended','Deleted'])){
                $where[] = ['h.status', '=', $param['status']];
            }
        }
        if(isset($param['keywords']) && $param['keywords'] !== ''){
            $where[] = ['h.name', 'LIKE', '%'.$param['keywords'].'%'];
        }

        // 获取子账户可见产品
        $res = hook('get_client_host_id', ['client_id' => get_client_id(false)]);
        $res = array_values(array_filter($res ?? []));
        foreach ($res as $key => $value) {
            if(isset($value['status']) && $value['status']==200){
                $hostId = $value['data']['host'];
            }
        }
        if(isset($hostId) && !empty($hostId)){
            $where[] = ['h.id', 'IN', $hostId];
        }

        $count = HostModel::alias('h')
            ->leftJoin('product p', 'h.product_id=p.id')
            ->join('upstream_product up', 'p.id=up.product_id AND up.res_module="mf_finance_dcim"')
            ->where($where)
            ->count();

        $host = HostModel::alias('h')
            ->field('h.id,h.name,h.status,h.active_time,h.due_time,p.name product_name')
            ->leftJoin('product p', 'h.product_id=p.id')
            ->join('upstream_product up', 'p.id=up.product_id AND up.res_module="mf_finance_dcim"')
            ->where($where)
            ->withAttr('status', function($val){
                return $val == 'Failed' ? 'Pending' : $val;
            })
            ->limit($param['limit'])
            ->page($param['page'])
            ->order($param['orderby'], $param['sort'])
            ->group('h.id')
            ->select()
            ->toArray();

        $result['data']['list']  = $host;
        $result['data']['count'] = $count;
        return json($result);
    }

    /**
     * 时间 2022-07-01
     * @title 日志
     * @desc 日志
     * @url /console/v1/remf_finance_dcim/:id/log
     * @method  GET
     * @author hh
     * @version v1
     * @param int id - 产品ID
     * @param string keywords - 关键字
     * @param int page - 页数
     * @param int limit - 每页条数
     * @param string orderby - 排序 id,description,create_time,ip
     * @param string sort - 升/降序 asc,desc
     * @return array list - 系统日志
     * @return int list[].id - 系统日志ID 
     * @return string list[].description - 描述 
     * @return string list[].create_time - 时间 
     * @return int list[].ip - IP 
     * @return int count - 系统日志总数
     */
    public function log(){
        $param = request()->param();

        $SystemLogModel = new SystemLogModel();
        $result = $SystemLogModel->systemLogList($param);
        return json($result);
    }

    /**
     * @title 升降级产品页面
     * @description 接口说明:升降级产品页面
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/upgrade_product
     * @method GET
     * @param   int id - 产品ID require
     * @return object old_host - 当前产品
     * @return object old_host.host - 产品组+产品名
     * @return object old_host.domain - 主机名
     * @return object old_host.description: - 描述
     * @return object old_host.pid - 商品ID
     * @return object old_host.uid -
     * @return  array host - 可升降级商品
     * @return int host[].pid - 商品ID
     * @return int host[].host - 商品名称
     * @return int host[].description - 描述
     * @return int host[].cycle - 周期
     * @return int host[].cycle[].setup_fee - 初装费
     * @return int host[].cycle[].price - 价格
     * @return int host[].cycle[].billingcycle - 周期
     * @return int host[].cycle[].billingcycle_zh - 周期
     * @return int host[].cycle[].amount - 金额
     * @return int host[].cycle[].saleproducts -
     */
    public function upgradeProduct(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
            ];

            $result = $RouteLogic->curl( 'upgrade/upgrade_product/'.$RouteLogic->upstream_host_id, $postData,'GET');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * @title 升降级产品页面提交(包括使用优惠码的情况)
     * @description 接口说明:升降级产品页面提交
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/upgrade_product
     * @method POST
     * @param   int id - 产品ID require
     * @param   int product_id - 商品ID require
     * @param   string billingcycle - 周期 require
     */
    public function upgradeProductPost(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id,
                'pid' => $param['product_id']??0,
                'billingcycle' => $param['billingcycle']??''
            ];

            $result = $RouteLogic->curl( 'upgrade/upgrade_product_post', $postData,'POST');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * @title 升降级产品页面
     * @description 接口说明:升降级产品页面
     * @author wyh
     * @time 2020-06-22
     * @url /console/v1/remf_finance_dcim/:id/upgrade_product_page
     * @param   int id - 产品ID require
     * @return object old_host - 原产品信息
     * @return int old_host.id - 原产品ID
     * @return string old_host.host - 商品名称
     * @return string old_host.domain - 主机名
     * @return string des - 新产品描述
     * @return float amount - 小计
     * @return float discount - 折扣
     * @return float amount_tota - 总计
     * @return array currency - 货币
     * @return string promo_code - 优惠码
     * @return string billingcycle - 周期
     * @return string billingcycle_zh - 周期中文
     * @method GET
     */
    public function getUpgradeProductPage(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id
            ];

            $result = $RouteLogic->curl( 'upgrade/upgrade_product_page', $postData,'GET');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * @title 升降级产品结算
     * @description 接口说明:升降级产品结算
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/checkout_upgrade_product
     * @method POST
     * @param   int id - 产品ID require
     * @return  object old_host - 原产品信息
     * @return  string old_host.host - 产品组+产品名
     * @return  string old_host.domain - 域名
     * @return  string des - 描述
     * @return  string amount - 差价
     * @return  string discount - 优惠
     * @return  string amount_total - 支付金额
     * @return  array payment - 支付方式
     * @return  int order_id - 订单ID
     * @return  int invoice_id - 账单ID
     */
    public function checkoutProductUpgrade(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id,
            ];

            $result = $RouteLogic->curl( 'upgrade/checkout_upgrade_product', $postData,'POST');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }


    /**
     * @title 升降级产品可配置项页面
     * @description 接口说明:升降级产品可配置项页面
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/upgrade_config
     * @method GET
     * @param   int id - 产品ID require
     * @return object host - 原产品信息
     * @return int host.oid - 可配置项ID
     * @return int host.option_name - 可配置项名称
     * @return int host.option_type - 类型
     * @return int host.qty - (类型为4时，qty为数量)
     * @return int host.suboption_name - 子项名称
     * @return int host.subid - 子项ID
     * @return int host.fee - 配置子项价格
     * @return int host.setupfee - 配置子项初装费
     * @return array options - 配置项信息,所有配置项
     * @return int options[].id -
     * @return string options[].option_name - 配置项名称
     * @return string options[].option_type - 配置项类型
     * @return int options[].qty_minimum - 最小值
     * @return int options[].qty_maximum - 最大值
     * @return array options[].sub - 所有子项
     * @return int options[].sub[].id - 子项ID
     * @return int options[].sub[].config_id - 配置项ID
     * @return string options[].sub[].option_name - 子项名称
     * @return int options[].sub[].qty_minimum -
     * @return int options[].sub[].qty_maximum -
     * @return string options[].sub[].show_pricing - 价格展示(下拉显示此值)
     */
    public function upgradeConfigPage(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id,
            ];

            $result = $RouteLogic->curl( 'upgrade/index/'.$RouteLogic->upstream_host_id, $postData,'GET');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * @title 升降级产品可配置项页面提交(包括使用优惠码)
     * @description 接口说明:升降级产品可配置项页面提交
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/upgrade_config
     * @method POST
     * @param   int id - 产品ID require
     * @param  array configoption - 配置,格式"configoption":{"配置项ID":"子项ID或者数量(当类型为数量时)"}
     */
    public function upgradeConfigPost(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id,
                'configoption' => $param['configoption']??[],
            ];

            $result = $RouteLogic->curl( 'upgrade/upgrade_config_post', $postData,'POST');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * @title 升降级产品可配置项页面
     * @description 接口说明:升降级产品可配置项
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/upgrade_config_page
     * @method GET
     * @param   int id - 产品ID require
     * @return float discount - 折扣
     * @return array currency - 货币
     * @return string promo_code - 优惠码
     * @return string billingcycle - 周期
     * @return string billingcycle_zh - 周期中文
     * @return array alloption - 所有配置
     * @return float subtotal - 总价(用这个)
     * @return float total - 总价
     */
    public function getUpgradeConfigPage(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id,
            ];

            $result = $RouteLogic->curl( 'upgrade/upgrade_config_page', $postData,'GET');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }

    /**
     * @title 升降级产品可配置项--结算
     * @description 接口说明:升降级产品可配置项--结算
     * @author wyh
     * @url /console/v1/remf_finance_dcim/:id/checkout_config_upgrade
     * @method POST
     * @param   int id - 产品ID require
     */
    public function checkoutConfigUpgrade(){
        $param = request()->param();

        $HostModel = HostModel::find($param['id']);
        if(empty($HostModel) || $HostModel['client_id'] != get_client_id() ){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_host_not_found')]);
        }

        try{
            $RouteLogic = new RouteLogic();
            $RouteLogic->routeByHost($param['id']);

            $postData = [
                'hid' => $RouteLogic->upstream_host_id,
            ];

            $result = $RouteLogic->curl( 'upgrade/checkout_config_upgrade', $postData,'POST');

        }catch(\Exception $e){
            return json(['status'=>400, 'msg'=>lang_plugins('res_mf_finance_dcim_act_exception')]);
        }
        return json($result);
    }


}
